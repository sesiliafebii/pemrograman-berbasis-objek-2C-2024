
package tugas1_modul1;

class Manusia { 
//Atribut
String nama,alamat;
int umur;

void Berjalan(){ //Method berjalan & berlari
    System.out.println( nama + " sedang Berjalan"); //menampilkan hasil output
}
void Berlari(){ //void tipe data yg tidak mengembalikan nilai apapun
    System.out.println("kemudian " + nama + " sekarang sedang Berlari"); 
}
}

public class Tugas1_modul1 {

    public static void main(String[] args) {
        Manusia orang1 = new Manusia (); //objek orang 1&2
        Manusia orang2 = new Manusia (); 
        
        orang1.nama = "Amanda";
        orang1.umur = 19;
        orang1.alamat = "Gresik ";
        System.out.println("nama : " + orang1.nama);
        System.out.println("umur : " + orang1.umur); 
        System.out.println("alamat : " + orang1.alamat);
        orang1.Berjalan();
        orang1.Berlari();
        
        orang2.nama = "Jamal";
        orang2.umur = 23;
        orang2.alamat = "Surabaya";
        System.out.println("nama : " + orang2.nama);
        System.out.println("umur : " + orang2.umur);
        System.out.println("alamat : " + orang2.alamat);
        orang2.Berjalan();
        orang2.Berlari();

    }
    
}