
package mahasiswa;

import java.util.Scanner;


public class Mahasiswa {
    //Atribut=variabel
    String Nama,NIM,Jurusan,Alamat;
     
    
    //Konstruktor
    public Mahasiswa(String inputNama, String inputNIM, String inputJurusan, String inputAlamat){
        Nama = inputNama;
        NIM = inputNIM;
        Jurusan = inputJurusan;
        Alamat = inputAlamat;
    }
    
    //Menampilkan informasi mahasiswa
    public void tampilkanInfo(){
        System.out.println("Nama: " + Nama);
        System.out.println("NIM: " + NIM);
        System.out.println("Jurusan: " + Jurusan);
        System.out.println("Alamat: " + Alamat);
    }
    public static void main(String[] args) { //memanggil metode saat program dijalankan
        Scanner scanner = new Scanner(System.in); //mendapatkan input dr pengguna

        // Meminta input dari pengguna
        System.out.print("Masukkan Nama Mahasiswa: "); //menghasilkan output
        String nama = scanner.nextLine(); //scanner membaca inputan
        System.out.print("Masukkan NIM Mahasiswa: ");
        String nim = scanner.nextLine();
        System.out.print("Masukkan Jurusan Mahasiswa: ");
        String jurusan = scanner.nextLine();
        System.out.print("Masukkan Alamat Mahasiswa: ");
        String alamat = scanner.nextLine();
        

        // Membuat objek Mahasiswa
        Mahasiswa mahasiswa = new Mahasiswa(nama, nim, jurusan, alamat);//paramater

        // Menampilkan informasi mahasiswa
        System.out.println("\nInformasi Mahasiswa:");
        mahasiswa.tampilkanInfo();
    }
}