
package manusia;


public class Manusia {

    
    String nama;
    String alamat;
    int umur;
  
    
    // Metode berjalan
    public void berjalan() {
        System.out.println(nama + " sedang berjalan.");
    }

    // Metode berlari
    public void berlari() {
        System.out.println(nama + " sedang berlari.");
    }

    
    // Metode utama (main method)
    public static void main(String[] args) {
       Manusia orang1 = new Manusia();
      
       
       orang1.nama = "Iklil";
       orang1.umur = 19;
       orang1.alamat = "Bangkalan";
       
       // untk mengakses informasi metode pada org pertama dan kedua
       orang1.berjalan();
       orang1.berlari();
       
        
        System.out.println("Nama  "+orang1.nama );
        System.out.println("Umur "+orang1.umur);
        System.out.println("Alamat "+orang1.alamat);
        
    }
    
}
