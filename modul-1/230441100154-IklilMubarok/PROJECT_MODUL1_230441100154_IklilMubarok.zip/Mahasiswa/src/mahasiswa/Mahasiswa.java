
package mahasiswa;
import java.util.Scanner;
class Mhs{
     String nama,nim,prodi,alamat;
}

public class Mahasiswa {

    public static void main(String[] args) {
        // TODO code application logic here
       
        Mhs orang1 = new Mhs();
        
        Scanner inputan = new Scanner(System.in);

        System.out.println("Ketik Nama Mahasiswa : ");
        orang1.nama = inputan.nextLine();

        System.out.println("Ketik Nim Mahasiswa : ");
        orang1.nim = inputan.nextLine();

        System.out.println("Ketik Prodi Mahasiswa : ");
        orang1.prodi = inputan.nextLine();

        System.out.println("Ketik Alamat Mahasiswa : ");
        orang1.alamat = inputan.nextLine();

        System.out.println();
        System.out.println("==========''=========");
        System.out.println("Nama Mahasiswa : " + orang1.nama);
        System.out.println("Nim Mahasiswa : " + orang1.nim);
        System.out.println("Prodi Mahasiswa : " + orang1.prodi);
        System.out.println("Alamat Mahasiswa : " + orang1.alamat);

        }

    }
